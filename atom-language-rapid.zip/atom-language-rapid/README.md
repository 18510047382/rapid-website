## Rapid language support in Atom
Adds syntax highlighting and snippets for Rapid in Atom.

Originally converted from the Rapid TextMate bundle.

Contributions are greatly appreciated. Please fork this repository and open a pull request to add snippets, make grammar tweaks, etc.
